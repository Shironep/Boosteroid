const extensionId = "agnaejlkbiiggajjmnpmeheigkflbnoo",
  assets = {
    logo: "https://i.imgur.com/Ldqj50W.png",
    unknownGame: "https://i.imgur.com/cnczdmM.png",
  }
let currentPath = window.location.pathname;

function getLang() {
  let supportedLangs = [
    "pt-BR",
    "en-US"
  ]

  const translations = {
    "en-US": {
      "platform": "Platform",
      "unknown": "Unknown Game",
      "looking": "Viewing game page",
      "browsing": "Browsing",
      "in": "In"
    },
    "pt-BR": {
      "platform": "Plataforma",
      "unknown": "Jogo desconhecido",
      "looking": "Visualizando página de jogo",
      "Browsing": "Navegando",
      "in": "em"
    }
  }

  let userLanguage = navigator.language;
  let langCode = supportedLangs.includes(userLanguage) ? userLanguage : "en-US";
  let translation = translations[langCode];

  return translation
}

chrome.runtime.sendMessage(extensionId, { mode: 'passive' }, function (response) {
  console.log('Presence registered')
});

setInterval(function () {
  if (currentPath !== window.location.pathname) {
    chrome.runtime.sendMessage(extensionId, { mode: 'passive' }, function (response) { });
  }
  currentPath = window.location.pathname;
}, 100);

function waitForElement(selector) {
  return new Promise((resolve) => {
    const intervalId = setInterval(() => {
      const element = document.querySelector(selector);
      if (element && element.textContent.trim() !== '') {
        clearInterval(intervalId);
        resolve(element);
      }
    }, 100);
  });
}

function processMessage(info, sender) {
  return new Promise(async (resolve, reject) => {
    let presenceData = {
      details: '',
      state: '',
      largeImageKey: assets.logo,
      startTimestamp: Math.floor(Date.now() / 1000),
      instance: true
    }

    const { pathname } = document.location;

    async function getGame(id) {
      let get = await fetch('https://raw.githubusercontent.com/Shironep/Boosteroid/main/games.json');
      const body = await get.json()
      return body[id]
    }

    try {
      switch (true) {
        case pathname === "/static/streaming/streaming.html": {
          const game = await getGame(window.localStorage.getItem("appId"));

          if (!game) {
            presenceData.details = getLang().unknown;
            presenceData.largeImageKey = assets.unknownGame;
          } else {
            presenceData.details = game.name;
            presenceData.state = `${getLang().platform}: ${game.platform}`;
            presenceData.largeImageKey = game.icon;
          }
          break;
        }
        case pathname.startsWith("/application/"): {
          const game = await getGame(pathname.replace('/application/', ''));

          if (!game) {
            presenceData.details = getLang().looking;
            presenceData.state = (await waitForElement("h1")).innerHTML;
            presenceData.largeImageKey = assets.unknownGame;
          } else {
            presenceData.details = getLang().looking;
            presenceData.state = game.name;
            presenceData.largeImageKey = game.icon;
            break;
          }
        }
        case pathname === "/dashboard": {
          const bruh = await waitForElement("button.tab-button--active");
          presenceData.details = getLang().browsing;
          presenceData.state = `${getLang().in}: ${bruh.innerHTML}`;
          break;
        }
        case pathname === "/profile/account/main": {
          presenceData.details = getLang().browsing;
          break;
        }
      }

      const response = {
        clientId: '1066889761928777848',
        presence: presenceData
      };
      resolve(response);
    } catch (error) {
      reject(error);
    }
  })
}

chrome.runtime.onMessage.addListener(function (info, sender, sendResponse) {
  processMessage(info, sender)
    .then(response => sendResponse(response))
    .catch(error => console.error(error));

  return true;
});